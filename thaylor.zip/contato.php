<?php require_once('header.php') ?>

<div class="container">
	<form class="form-group">
		
	</form>
</div>

<?php require_once('footer.php') ?>