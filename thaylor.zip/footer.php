<div class="footer">
	<div class="container text-center">
		<p>Thaylor Carvalho - 2019</p>
		<a href="https://www.linkedin.com/in/thaylorcs/" target="_blank"><i class="fab fa-linkedin"></i></a>
		<a href="https://github.com/thaylorcs" target="_blank"><i class="fab fa-github-square"></i></a>
		<a href="mailto:contato@thaylorcarvalho.com"><i class="fas fa-envelope"></i></a>
	</div>
</div>

</body>
</html>